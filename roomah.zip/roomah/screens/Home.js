import React, { Component } from 'react';

import RegisterForm from '../components/RegisterForm';


export default class Home extends Component {
  render() {
    return (
      <RegisterForm />
    );
  }
}
