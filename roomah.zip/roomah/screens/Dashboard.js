import React, { Component } from 'react';
import { Text} from 'react-native';




// or any pure javascript modules available in npm
import { Card } from 'react-native-elements'; // Version can be specified in package.json


export default class Dashboard extends Component {
  render() {
    return (
        <Card>
          <Text>lklk</Text>
        </Card>
    );
  }
}
